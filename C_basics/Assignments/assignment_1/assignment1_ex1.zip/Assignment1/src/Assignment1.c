/*
 ============================================================================
 Name        : Assignment1.c
 Author      : muhammad
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	printf("c programming");
	return 0;
}
